#include <stdlib.h>
#include <stdio.h>

#define N_PARADAS 5 //numero de paradas de la ruta
#define EN_RUTA 0 //autobus en ruta
#define EN_PARADA 1 //autobus en la parada
#define MAX_USUARIOS 40 //capacidad del autobus
#define USUARIOS 4 //numero de USUARIOS

//estado inicial
int estado = EN_RUTA;
int parada_actual = 0;
int n_ocupantes = 0;

int esperando_parada[N_PARADAS];

int esperando_bajar[N_PARADAS];

pthread_mutex_t mutex;
pthread_cond_t vcBus, vcUser;

void Autobus_En_Parada(){
	//Ajustar el estado y bloquear al autobus hasta que no haya pasajeros que quieran
	//bajar y/o subir la parada actual. Despues se pone en marcha
	pthread_mutex_lock(&mutex);
	estado = EN_PARADA;
	printf("El autobus ha estacionado en la parada %d \n", parada_actual);
	pthread_cond_broadcast(&vcUser);
	while(esperando_parada[parada_actual] > 0 || esperando_bajar[parada_actual] > 0){
		printf("subir %d bajar %d \n", esperando_parada[parada_actual], esperando_bajar[parada_actual]);
		pthread_cond_wait(&vcBus, &mutex);
	}
	estado = EN_RUTA;
	pthread_mutex_unlock(&mutex);
}

void Conducir_Hasta_Siguiente_Parada(){
	//Establecer un retardo que simule el treyecto y actualizar numero de parada
	printf("Conduciendo hasta siguiente parada...\n");
	sleep(5);
	pthread_mutex_lock(&mutex);
	if(parada_actual == N_PARADAS)
		parada_actual = 0;
	else
		parada_actual++;
	pthread_mutex_unlock(&mutex);
}

void Subir_Autobus(int id_usuario, int origen) {

	/* El usuario indicara que quiere subir en la parada origen, esprara a que el
	autobus se pare en dicha parada y subira. El id_usuario puede utilizarse para
	proporcionar informacion de depuracion	*/

	pthread_mutex_lock(&mutex);
	printf("Usuario %d esperando en la parada %d \n", id_usuario, origen);
	while(parada_actual != origen)
		pthread_cond_wait(&vcUser, &mutex);

	n_ocupantes++;
	esperando_parada[parada_actual]--;
	printf("El usuario %d se ha subido \n", id_usuario);
	/*if(esperando_parada[parada_actual] == 0)
		pthread_cond_signal(&vcBus);
	else
		printf("Quedan %d por subir \n", esperando_parada[parada_actual]);*/
	pthread_cond_signal(&vcBus);

	pthread_mutex_unlock(&mutex);
}

void Bajar_Autobus(int id_usuario, int destino) {

	/* El usuario indicara que quiere bajar en la parada destino, esperara a que
	el autobus se pare en dicha parada y bajara. El id_usuario puede utilizarse para
	proporcionar informacion de depuracion */

	pthread_mutex_lock(&mutex);
	while(parada_actual != destino)
		pthread_cond_wait(&vcUser, &mutex);

	n_ocupantes--;
	esperando_bajar[parada_actual]--;
	printf("El usuario %d se ha bajado \n", id_usuario);
	/*if(esperando_bajar[parada_actual] = 0)
		pthread_cond_signal(&vcBus);
	else
		printf("Quedan %d por bajar \n", esperando_bajar[parada_actual]);*/
	pthread_cond_signal(&vcBus);
	pthread_mutex_unlock(&mutex);

}

void * thread_autobus(void * args) {
	while(1) {
		Autobus_En_Parada();

		Conducir_Hasta_Siguiente_Parada();
	}
}

void *thread_usuario(void *args) {
	int id_usuario = (int) args;
	int a, b;

	while(1) {
		a = rand() % N_PARADAS;
		do {
			b = rand() % N_PARADAS;
		} while(a == b);
		Usuario(id_usuario, a, b);
	}
}

void Usuario(int id_usuario, int origen, int destino) {
	//Esperar a que el autobus este en parada origen para subir
	pthread_mutex_lock(&mutex);
	esperando_parada[origen]++;
	pthread_mutex_unlock(&mutex);

	Subir_Autobus(id_usuario, origen);
	// Bajarme en estacion destino
	pthread_mutex_lock(&mutex);
	esperando_bajar[destino]++;
	pthread_mutex_unlock(&mutex);

	Bajar_Autobus(id_usuario, destino);
}

int main(int argc, char* argv[])
{
	/* ..

	PROPONER PSEUDOCODIGO Y A PARTIR DE AHI PASAR A IMPLEMENTAR

. To be completed ... */
	int i;

	// Definicion de variables locales a main

	pthread_t autobus;
	pthread_t users[MAX_USUARIOS];
	pthread_mutex_init(&mutex, NULL);
	pthread_create(&autobus, NULL, &thread_autobus, NULL);

	for(i = 0; i < USUARIOS; i++){
		pthread_create(&users[i], NULL, &thread_usuario, (void*) i);
	}

	for(int j = 0; j < USUARIOS; j++) {
		pthread_join(users[j], NULL);
	}

	//pthread_join(autobus, NULL);

	printf("He salido de los dos for \n");
	pthread_mutex_destroy(&mutex);
	pthread_cond_destroy(&vcBus);

	return 0;
}

