#!/bin/bash

mkdir temp

#fichero 1
cp ./src/fuseLib.c ./temp/fuseLib.c
cp ./temp/fuseLib.c ./montaje/fuseLib.c

#fichero2
cp ./src/myFS.h ./temp/myFS.h
cp ./temp/myFS.h ./montaje/myFS.h

./my-fsck virtual-disk

diff -q ./src/fuseLib.c ./montaje/fuseLib.c
diff -q ./src/myFS.h ./montaje/myFS.h

truncate -s -4096 ./temp/fuseLib.c
truncate -s -4096 ./montaje/fuseLib.c

./my-fsck virtual-disk

diff -q ./src/fuseLib.c ./montaje/fuseLib.c

cp ./src/MyFileSystem.c ./montaje/MyFileSystem.c

./my-fsck virtual-disk

diff -q ./src/MyFileSystem.c ./montaje/MyFileSystem.c

truncate -s +4096 ./temp/myFS.h
truncate -s +4096 ./montaje/myFS.h

./my-fsck virtual-disk

diff -q ./src/myFS.h ./montaje/myFS.h
